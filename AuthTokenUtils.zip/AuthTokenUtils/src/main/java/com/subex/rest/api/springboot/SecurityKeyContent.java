package com.subex.rest.api.springboot;

public class SecurityKeyContent
{
	private String privatekeyContent;
	private String publicKeyContent;

	public String getPrivatekeyContent()
	{
		return privatekeyContent;
	}
	public void setPrivatekeyContent(String privatekeyContent)
	{
		this.privatekeyContent = privatekeyContent;
	}
	public String getPublicKeyContent()
	{
		return publicKeyContent;
	}
	public void setPublicKeyContent(String publicKeyContent)
	{
		this.publicKeyContent = publicKeyContent;
	}

}
