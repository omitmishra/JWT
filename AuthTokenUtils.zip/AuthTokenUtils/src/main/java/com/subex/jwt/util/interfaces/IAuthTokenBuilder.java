package com.subex.jwt.util.interfaces;

import com.auth0.jwt.JWTCreator;

public interface IAuthTokenBuilder {
	public String buildAuthToken(JWTCreator.Builder builder) throws Exception;
}
