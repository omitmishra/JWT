package com.subex.jwt.util.impl;

import java.util.Date;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;

public class CustomJWTCreator
{
	JWTCreator.Builder builder = null;

	private CustomJWTCreator()
	{
		this.builder = JWT.create();
		long currentTimeInMillis = System.currentTimeMillis();
		long expiryTimeInMillis = currentTimeInMillis + 60000; // 60 sec

		builder.withIssuer("rocfm"); // default will be rocfm
		builder.withSubject("system"); // default user will be system
		builder.withAudience("localhost"); // default user will be system
		builder.withExpiresAt(new Date(expiryTimeInMillis));
		//builder.withIssuedAt(new Date(currentTimeInMillis));
		//builder.withNotBefore(new Date(currentTimeInMillis));
	}

	public static JWTCreator.Builder createBuilder()
	{

		return new CustomJWTCreator().getBuilder();
	}

	private JWTCreator.Builder getBuilder()
	{
		return builder;
	}
}
