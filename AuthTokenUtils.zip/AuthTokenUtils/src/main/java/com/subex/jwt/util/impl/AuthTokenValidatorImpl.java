package com.subex.jwt.util.impl;

import java.security.interfaces.RSAPublicKey;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.subex.jwt.util.interfaces.IAuthTokenValidator;
import com.subex.jwt.util.interfaces.IKeyContentFetcher;

public class AuthTokenValidatorImpl implements IAuthTokenValidator {

	private RSAPublicKey publicKeyContent;

	public AuthTokenValidatorImpl(IKeyContentFetcher keyContentFetcher) throws Exception {
		this.publicKeyContent = keyContentFetcher.getPublicKeyContent();
	}

	@Override
	public DecodedJWT getDecodedJWT(String jwtToken) throws Exception {

		if (this.publicKeyContent == null)
			throw new Exception("Failed to build validate JWT token. PublicKeyContent key found be null.");

		/*
		 * Algorithm.RSA256(publicKeyContent) will get deprecated soon. Instead using
		 * Algorithm.RSA256(publicKeyContent, null) Signature validation requires only
		 * publicKeyContent
		 */
		Algorithm algorithm = Algorithm.RSA256(this.publicKeyContent, null);

		JWTVerifier verifier = JWT.require(algorithm).build();
		return verifier.verify(jwtToken);
	}

	@Override
	public final void validateSignature(String jwtToken) throws Exception {
		try {
			getDecodedJWT(jwtToken);
		} catch (Exception exp) {
			throw exp;
		}
	}

	@Override
	public void validateClaims(String jwtToken) throws Exception {
		try {
			DecodedJWT decodedJWT = getDecodedJWT(jwtToken);
			System.out.println("Decoded Claims:: Algo : " + decodedJWT.getAlgorithm());
			System.out.println("Decoded Claims:: Content Type : " + decodedJWT.getContentType());
			System.out.println("Decoded Claims:: Issuer : " + decodedJWT.getIssuer());
			System.out.println("Decoded Claims:: Subject : " + decodedJWT.getSubject());
			System.out.println("Decoded Claims:: Audience : " + decodedJWT.getAudience());
		} catch (Exception exp) {
			throw exp;
		}
	}

}
