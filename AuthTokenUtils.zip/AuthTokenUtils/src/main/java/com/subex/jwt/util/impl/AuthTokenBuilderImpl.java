package com.subex.jwt.util.impl;

import java.security.interfaces.RSAPrivateKey;

import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.subex.jwt.util.interfaces.IAuthTokenBuilder;

import com.subex.jwt.util.interfaces.IKeyContentFetcher;

public class AuthTokenBuilderImpl implements IAuthTokenBuilder {

	RSAPrivateKey privatekeyContent;

	public AuthTokenBuilderImpl(IKeyContentFetcher keyContentFetcher) throws Exception {
		if (keyContentFetcher == null)
			throw new Exception("Failed to build JWT token. KeyContentFetcher found to be null.");
		this.privatekeyContent = keyContentFetcher.getPrivatekeyContent();
	}

	public AuthTokenBuilderImpl(RSAPrivateKey privatekeyContent) {
		this.privatekeyContent = privatekeyContent ;
	}

	@Override
	public String buildAuthToken(JWTCreator.Builder builder) throws Exception {

		if (builder == null)
			throw new Exception("Failed to build JWT token. JWTCreator.Builder found to be null.");
		
		if(this.privatekeyContent == null)
			throw new Exception("Failed to build JWT token. PrivatekeyContent found to be null.");
		/*
		 * Algorithm.RSA256(privatekeyContent) will get deprecated soon. Instead using
		 * Algorithm.RSA256(null, privatekeyContent) Token building requires only
		 * privatekeyContent
		 */
		Algorithm algorithm = Algorithm.RSA256(null, this.privatekeyContent);

		return builder.sign(algorithm);
	}

}
