package com.subex.jwt.util.interfaces;

import com.auth0.jwt.interfaces.DecodedJWT;

public interface IAuthTokenValidator {
	public DecodedJWT getDecodedJWT(String jwtToken) throws Exception;

	public void validateSignature(String jwtToken) throws Exception;

	public void validateClaims(String jwtToken) throws Exception;
}