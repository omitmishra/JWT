package com.subex.jwt.util.interfaces;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

public interface IKeyContentFetcher {

	public RSAPrivateKey getPrivatekeyContent() throws Exception;
	public RSAPublicKey getPublicKeyContent() throws Exception;

	public RSAPrivateKey getPrivatekeyContent(String privateKeyContent) throws Exception ;
	public RSAPublicKey getPublicKeyContent(String publicKeyContent) throws Exception ;

}
