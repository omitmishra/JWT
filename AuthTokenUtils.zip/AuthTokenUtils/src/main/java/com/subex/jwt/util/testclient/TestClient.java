package com.subex.jwt.util.testclient;

import java.io.File;

import com.auth0.jwt.JWTCreator;
import com.subex.jwt.util.impl.AuthTokenBuilderImpl;
import com.subex.jwt.util.impl.AuthTokenValidatorImpl;
import com.subex.jwt.util.impl.CustomJWTCreator;
import com.subex.jwt.util.impl.DefaultKeyContentFetcher;
import com.subex.jwt.util.interfaces.IAuthTokenBuilder;
import com.subex.jwt.util.interfaces.IAuthTokenValidator;
import com.subex.jwt.util.interfaces.IKeyContentFetcher;

public class TestClient {

	public static void main(String[] args) {
		
		char fileDescriptor  = File.separatorChar ;
		String currentDirectory = System.getProperty("user.dir") ;		
		currentDirectory = currentDirectory + fileDescriptor + "sample" +  fileDescriptor ;
		
		String publicKeyFilePath = currentDirectory + "rsa_key.pub";
		String privateKeyFilePath = currentDirectory + "private_key";
		String jwtToken = "";

		/*
		 * Initialize keyContentFetcher with appropriate private/public file paths.
		 * Constructor does not throw exception
		 */
		IKeyContentFetcher keyContentFetcher = new DefaultKeyContentFetcher("","");

		/******************** Client Side Implementation *******************/

		JWTCreator.Builder builder = CustomJWTCreator.createBuilder();
		/*
		 * Add custom claims jwtClaims.addToPayloadClaim(String name, Object value)
		 * 
		 */
		try {

			IAuthTokenBuilder jwtBuilder = new AuthTokenBuilderImpl(keyContentFetcher);
			jwtToken = jwtBuilder.buildAuthToken(builder);

			//System.out.println("JWT Token : " + jwtToken);
		} catch (Exception exp) {
			System.out.println("Token creation failed:-");
			System.out.println(exp.toString());
			exp.printStackTrace();
			System.exit(1);

		}

		
		/******************** Server Side Implementation *******************/

		try {

			IAuthTokenValidator jwtValidator = new AuthTokenValidatorImpl(keyContentFetcher);

			// Success case
			jwtValidator.validateSignature(jwtToken);
			System.out.println("Successfully validated signature.");

			// Success case
			jwtValidator.validateClaims(jwtToken);
			System.out.println("Successfully validated claims.");

			// Failure case
			Thread.sleep(80000);
			jwtValidator.validateClaims(jwtToken);

		} catch (Exception exp) {
			System.out.println("Token validation failed:-" + exp.toString());
			System.out.println(exp.toString());
			exp.printStackTrace();
			System.exit(1);
		}
	}

}
